//  Task 1
// Добавьте кнопку .b-1, которая запускает функцию f1. Функция присваивает блоку .out-1 ширину 200px, высоту 40px.


function f1() {
    let out_1 = document.querySelector('.out-1');
    out_1.style.width = "200px";
    out_1.style.heigth = "40px";
}

document.querySelector('.b-1').onclick = f1;

//  Task 2
// По нажатию кнопки b-2 запускайте функцию f2, которая присваивает блоку out-2 класс .bg-2.

function f2() {
    let out_2 = document.querySelector('.out-2');
    out_2.classList.add("bg-2");
}

document.querySelector('.b-2').onclick = f2;


//  Task 3
// По нажатию кнопки b-3 запускайте функцию f3, которая удаляет у блока out-3 класс .bg-3.

function f3() {
    let out_3 = document.querySelector('.out-3');
    out_3.classList.remove("bg-3");
}

document.querySelector('.b-3').onclick = f3;

//  Task 4
// По нажатию кнопки b-4 запускайте функцию f4, которая делает toggle класса bg-4 для блока out-4.


function f4() {
    let out_4 = document.querySelector('.out-4');
    out_4.classList.toggle("bg-4");
}

document.querySelector('.b-4').onclick = f4;


//  Task 5
// По нажатию b-5 запускайте функцию f5, которая проверяет наличие класса bg-4 у блока out-4 (да, именно bg-4 у out-4 ). Результат - true или false, выводите в out-5.

function f5() {
    let out_5 = document.querySelector('.out-5');
    let out_4 = document.querySelector('.out-4');
    if (out_4.classList.contains("bg-4")) {
        out_5.innerHTML = true;
    }
    else {
        out_5.innerHTML = false;
    }
}

document.querySelector('.b-5').onclick = f5;


//  Task 6
// По нажатию b-6 запускайте функцию f6, которая выводит в out-6 количество параграфов с классом p-6.

function f6() {
    let out_6 = document.querySelector('.out-6');
    let p_6 = document.querySelectorAll('.p-6');
    for (let i = 1; i <= p_6.length; i++) {
        out_6.innerHTML = i;
    }
}

document.querySelector('.b-6').onclick = f6;


//  Task 7
// По нажатию кнопки b-7 запускайте функцию f7, которая присваивает блокам out-7 класс .bg-7. Обратите внимание, что данных блоков больше одного, следовательно нужен цикл.

let blocks7 = document.querySelectorAll('.out-7');

function f7() {
    //внутри цикла blocks7[i].classList....
    for (let i = 0; i < blocks7.length; i++) {
        blocks7[i].classList.add("bg-7");
    }
}

document.querySelector('.b-7').onclick = f7;


//  Task 8
// По нажатию кнопки b-8 запускайте функцию f8, которая делает toggle блокам out-8 класс .bg-8. Обратите внимание, что данных блоков больше одного, следовательно нужен цикл.

let blocks8 = document.querySelectorAll('.out-8');

function f8() {
    //внутри цикла blocks8[i].classList....
    for (let i = 0; i < blocks8.length; i++) {
        blocks8[i].classList.toggle("bg-8");
    }
}

document.querySelector('.b-8').onclick = f8;


//  Task 9
// Усложним предыдущие задачи. С помощью цикла повесьте на блоки out-9 событие клик. По клику должна выполняться функция f9. Функция, должна добавлять класс bg-9 тому out-9 на котором кликнули.

function f9() {
    //this.classList...  // все решается одной строкой
    this.classList.add("bg-9");
}

let div9 = document.querySelectorAll('.out-9');

for (let i = 0; i < div9.length; i++) {
    div9[i].onclick = f9;
}


//  Task 10
// Усложним предыдущие задачи. С помощью цикла повесьте на блоки out-10 событие клик. По клику должна выполняться функция f10. Функция, должна делать toggle класса bg-10 тому out-10 на котором кликнули.

//let div10 = тут получите все out-10

function f10() {
    this.classList.toggle("bg-10");
}

let out_10 = document.querySelectorAll('.out-10');

for (let i = 0; i < out_10.length; i++) {
    out_10[i].onclick = f10;
}

// а тут цикл, похожий на предыдущее задание



//  Task 11
// Добавьте кнопку .b-11, которая запускает функцию f11. Функция создает через createElement div c текстом 25 и добавляет его через append в out-11.


function f11() {
    let div_11 = document.createElement("div");
    div_11.innerHTML = "25";
    let out_11 = document.querySelector('.out-11');
    out_11.append(div_11);
}

document.querySelector('.b-11').onclick = f11;

//  Task 12
// Добавьте кнопку .b-12, которая запускает функцию f12. Функция создает через createElement div c текстом 12 и добавляет ему класс bg-12. Созданный div добавляется в out-12.


function f12() {
    let out_12 = document.querySelector('.out-12');
    let div_12 = document.createElement("div");
    div_12.innerHTML = "12";
    div_12.classList.add("bg-12");
    out_12.append(div_12);
}

document.querySelector('.b-12').onclick = f12;

//  Task 13
// Добавьте кнопку .b-13, которая запускает функцию f13. Функция создает через createElement div c текстом pushMe и добавляет ему класс bg-13. Также, созданному div добавляется событие onclick, по которому выполняется функция f13_1. Созданный div добавляется в out-13.

function f13() {
    let out_13 = document.querySelector('.out-13');
    let div_13 = document.createElement('div');
    div_13.innerHTML = "PushMe";
    div_13.classList.add("bg-13");
    out_13.append(div_13);
    div_13.onclick = f13_1;
}

function f13_1() {
    document.querySelector('.out-13-1').innerHTML += this.innerHTML;
}


document.querySelector('.b-13').onclick = f13;

//  Task 14
// Добавьте кнопку .b-14, которая запускает функцию f14. Функция создает через createElement div c текстом 14 и добавляет ему класс bg-14. Созданный div добавляется в out-14 с помощью prepend.


function f14() {    
    let out_14 = document.querySelector('.out-14');
    let div_14 = document.createElement('div');
    div_14.innerHTML = "14";
    div_14.classList.add("bg-14");
    out_14.prepend(div_14);
}

document.querySelector('.b-14').onclick = f14;

//  Task 15
// Добавьте кнопку .b-15, которая запускает функцию f15. Функция создает через createElement div c текстом 15 и добавляет ему класс bg-15. Созданный div добавляется в out-15 с помощью before.

function f15() {
    let out_15 = document.querySelector('.out-15');
    let div_15 = document.createElement('div');
    div_15.innerHTML = "15";
    div_15.classList.add("bg-15");
    out_15.before(div_15);
}

document.querySelector('.b-15').onclick = f15;

//  Task 16
// Добавьте кнопку .b-16, которая запускает функцию f16. Функция создает через createElement div c текстом 16 и добавляет ему класс bg-16. Созданный div добавляется в out-16 с помощью after.

function f16() {
    let out_16 = document.querySelector('.out-16');
    let div_16 = document.createElement('div');
    div_16.innerHTML = "16";
    div_16.classList.add("bg-16");
    out_16.after(div_16);
}

document.querySelector('.b-16').onclick = f16;

//  Task 17
// Добавьте кнопку .b-17, которая запускает функцию f17. Функция создает через createElement div c текстом 17 и добавляет ему класс bg-17. Созданный div заменяет  out-17 с помощью replaceWith.

function f17() {
    let out_17 = document.querySelector('.out-17');
    let div_17 = document.createElement('div');
    div_17.innerHTML = "17";
    div_17.classList.add("bg-17");
    out_17.replaceWith(div_17);
}

document.querySelector('.b-17').onclick = f17;

//  Task 18
// Добавьте кнопку .b-18, которая запускает функцию f18. Функция с помощью getAttribute получает data-b атрибут с параграф p-18 и выводит в out-18.

function f18() {
    let out_18 = document.querySelector('.out-18');
    let data_b = document.querySelector('.p-18').getAttribute("data-b");
    out_18.innerHTML = data_b;
}

document.querySelector('.b-18').onclick = f18;

//  Task 19
// Добавьте кнопку .b-19, которая запускает функцию f19. Функция с помощью getAttribute получает data-b атрибут с параграфов p-19 и выводит в out-19 через пробел. Обратите внимание, что элементов p-19 больше одного.

function f19() {
    let out_19 = document.querySelector('.out-19');
    let p_19 = document.querySelectorAll('.p-19');
    let str = "";
    for (let i = 0; i < p_19.length; i++) {
        str += p_19[i].getAttribute("data-b") + " ";
    }
    out_19.innerHTML = str;
}

document.querySelector('.b-19').onclick = f19;

//  Task 20
// Добавьте кнопку .b-20, которая запускает функцию f20. Функция с помощью setAttribute присваивает атрибут title="go" в div.out-20.

function f20() {
    let out_20 = document.querySelector('.out-20');
    let data_20 = out_20.setAttribute("title", "go");
}

document.querySelector('.b-20').onclick = f20;